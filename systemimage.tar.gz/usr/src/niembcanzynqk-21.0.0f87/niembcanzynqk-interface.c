#undef __NO_VERSION__
#include <linux/version.h>

#include <linux/string.h>
#include <linux/errno.h>
#ifdef MODULE
   #if defined(CONFIG_MODVERSIONS) && !defined(MODVERSIONS)
      #define MODVERSIONS
   #endif

   #ifdef MODVERSIONS
      #include <config/modversions.h>
   #endif

   #include <linux/module.h>
#endif

#include "nikal.h"

#ifdef MODULE_LICENSE
   #ifdef nNIKAL100_kCopyrightString
      MODULE_LICENSE(nNIKAL100_kCopyrightString);
   #endif
#endif

#ifdef MODULE_AUTHOR
   #ifdef nNIKAL100_kAuthorString
      MODULE_AUTHOR(nNIKAL100_kAuthorString);
   #endif
#endif

#ifdef MODULE_DESCRIPTION
   #ifdef nNIKAL100_kDescriptionString
      MODULE_DESCRIPTION(nNIKAL100_kDescriptionString);
   #endif
#endif


#include <linux/mod_devicetable.h>

int nNIAPAL200_driverEntry(struct nNIKAL100_tDriver *driver);

static struct nNIKAL100_tDriver atomicDriver;
static void* nativeDriverRegistration;

/* native driver registration functions. These functions are auto-generated */
void *registerNativeDriver(nNIKAL100_tDriver*);
void unregisterNativeDriver(void*);

int init_module(void)
{
   atomicDriver.module = THIS_MODULE;

   if (nNIAPAL200_driverEntry(&atomicDriver))
      return -ENODEV;

   nativeDriverRegistration = registerNativeDriver(&atomicDriver);

   if (nativeDriverRegistration == NULL)
   {
      if (atomicDriver.unload)
         atomicDriver.unload(&atomicDriver);
      return -ENODEV;
   }

   return 0;
}

void cleanup_module(void)
{
   unregisterNativeDriver(nativeDriverRegistration);

   if (atomicDriver.unload)
      atomicDriver.unload(&atomicDriver);
}

/* native driver registration is no-op */
void *registerNativeDriver(struct nNIKAL100_tDriver* ignore)
{
   static int some_non_null_storage_ignoreme;
   return &some_non_null_storage_ignoreme;
}
void unregisterNativeDriver(void* ignore) { }


#define nNIKAL100_mExportSymbol EXPORT_SYMBOL
