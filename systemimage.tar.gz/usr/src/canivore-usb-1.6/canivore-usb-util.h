#include <linux/module.h>
#include <linux/uaccess.h>

extern uint8_t const canivore_usb_max_frame_sz;
extern size_t const canivore_usb_default_rx_buffer_cap;

extern uint8_t const canivore_usb_breq_get_firm_compa_id;
extern uint8_t const canivore_usb_breq_get_app_firm_vers;
extern uint8_t const canivore_usb_breq_set_disable;
extern uint8_t const canivore_usb_breq_set_enable;
extern uint8_t const canivore_usb_breq_get_serial;
extern uint8_t const canivore_usb_breq_get_mac;

extern uint8_t const canivore_usb_breq_set_bittiming;
extern uint8_t const canivore_usb_breq_set_data_bittiming;
extern uint8_t const canivore_usb_breq_get_bt_const;
extern uint8_t const canivore_usb_breq_get_data_bt_const;
extern uint8_t const canivore_usb_breq_get_timestamp;
extern uint8_t const canivore_usb_breq_set_timestamp;
extern uint8_t const canivore_usb_breq_get_rx_buffer_cap;

extern uint8_t const canivore_usb_ioctl_ifprot;
extern uint8_t const canivore_usb_ioctl_diag;
extern uint8_t const canivore_usb_ioctl_busutil;

extern uint16_t const canivore_usb_loopback;
extern uint16_t const canivore_usb_listenonly;
extern uint16_t const canivore_usb_3_samples;
extern uint16_t const canivore_usb_one_shot;
extern uint16_t const canivore_usb_berr_reporting;
extern uint16_t const canivore_usb_fd;
extern uint16_t const canivore_usb_presume_ack;
extern uint16_t const canivore_usb_fd_non_iso;

extern uint16_t const canivore_usb_inst_vars_sz;

typedef struct _canivore_usb_can_flags_t {
	unsigned esi : 1;
	unsigned brs : 1;
	unsigned fdf : 1;
} canivore_usb_can_flags_t;

typedef struct _canivore_usb_err_flags_t {
	unsigned restart : 1;
	unsigned bus_error : 1;
	unsigned arbitration_lost : 1;
} canivore_usb_err_flags_t;

typedef struct _canivore_usb_rx_handlers_t {
	int(*rx_handler_1)(void *device, void const *frameEndPt);
	int(*rx_handler_2)(void *device, void const *frameEndPt1, void const *frameEndPt2);
	int(*rx_handler_3)(void *device, void const *frameEndPt1, void const *frameEndPt2, void const *frameEndPt3);
	int(*rx_resync_handler)(void *device);
	int(*rx_busutil_handler)(void *device, uint8_t busutil);
	int(*rx_error_handler)(void *device, uint8_t tec, uint8_t rec, canivore_usb_err_flags_t err_flags);
	int(*rx_dropped_handler)(void *device);
} canivore_usb_rx_handlers_t;

void canivore_usb_fill_enable_req(uint16_t *enableReq, uint8_t len, uint16_t can_flags, size_t rx_buffer_cap);

bool canivore_usb_is_frame_fd(void const *frameEndPt);

void canivore_usb_get_single_frame_data(void const *frameEndPt, uint32_t *can_id, uint8_t *len,
				uint8_t *data, uint64_t *timestamp_ns, canivore_usb_can_flags_t *flags);

void canivore_usb_get_a_frame_data(void const *frameEndPtA, void const *frameEndPtB, uint32_t *can_id, uint8_t *len,
				uint8_t *data, uint64_t *timestamp_ns, canivore_usb_can_flags_t *flags);

void canivore_usb_get_c_frame_data(void const *frameEndPtC, void const *frameEndPtB, uint32_t *can_id, uint8_t *len,
				uint8_t *data, uint64_t *timestamp_ns, canivore_usb_can_flags_t *flags);

void canivore_usb_set_rx_handlers(canivore_usb_rx_handlers_t const *rx_handlers, void *inst_vars);

int canivore_usb_manage_frame_rx(void *dev, void const *frameEndPt, size_t frameEndPtLen, void *inst_vars);

uint8_t canivore_usb_get_frame_data_len(void const *frame);

typedef int (*canivore_usb_get_tx_size_t)(void const *frame);
typedef int (*canivore_usb_prepare_frame_tx_t)(void *frame, uint32_t can_id, uint8_t len, uint8_t const *data, uint64_t timestamp_ns,
					canivore_usb_can_flags_t const *flags, void *inst_vars);

int canivore_usb_get_tx1_size(void const *frame); // canivore_usb_get_tx_size_t

int canivore_usb_get_tx2_size(void const *frame); // canivore_usb_get_tx_size_t

int canivore_usb_prepare_frame_tx1(void *frame, uint32_t can_id, uint8_t len, uint8_t const *data, uint64_t timestamp_ns,
				canivore_usb_can_flags_t const *flags, void *inst_vars); // canivore_usb_prepare_frame_tx_t

int canivore_usb_prepare_frame_tx2(void *frame, uint32_t can_id, uint8_t len, uint8_t const *data, uint64_t timestamp_ns,
				canivore_usb_can_flags_t const *flags, void *inst_vars); // canivore_usb_prepare_frame_tx_t

uint16_t canivore_usb_get_ioctl_tx_len(void const *data_ifr);

void canivore_usb_fill_ioctl_rx_info(void const *data_ifr, uint16_t *rx_len, uint16_t *rx_timeout);

uint32_t canivore_usb_fill_ioctl_tx_data(void const *data_ifr, uint8_t *data, uint16_t len);

uint32_t canivore_usb_fill_ioctl_rx_data(void *data_ifr, uint8_t const *data, uint16_t len);

uint32_t canivore_usb_fill_ioctl_tx_error(void *data_ifr);

uint32_t canivore_usb_fill_ioctl_rx_error(void *data_ifr);
