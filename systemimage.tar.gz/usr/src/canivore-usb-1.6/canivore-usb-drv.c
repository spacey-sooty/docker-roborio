/**
 * For useful documentation on USB kernel apis
 * @link https://www.oreilly.com/library/view/linux-device-drivers/0596005903/ch13.html 
 */

/*
 * CTR Electronics USB-to-CANbus device driver for CANivore.
 *
 * Copyright (C) 2021 CTR Electronics
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; version 2 of the License.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/signal.h>
#include <linux/usb.h>

#include <linux/can.h>
#include <linux/can/dev.h>
#include <linux/can/error.h>

#include "canivore-usb-util.h"

#define CANIVORE_USB_VENDOR_ID 0x29CA
#define CANIVORE_USB_PRODUCT_ID 0x4481
#define CANIVORE_USB_INTF_PROTOCOL 0xFD

#define CANIVORE_USB_LISTEN_ONLY          BIT(0)
#define CANIVORE_USB_LOOP_BACK            BIT(1)

#define CANIVORE_USB_TIMEOUT 500

typedef struct _canivore_usb_bittiming_t {
	uint32_t prop_seg;
	uint32_t phase_seg1;
	uint32_t phase_seg2;
	uint32_t sjw;
	uint32_t brp;
} __packed canivore_usb_bittiming_t;

typedef struct _canivore_usb_bt_const_t {
	uint32_t feature;
	uint32_t fclk_can;
	uint32_t tseg1_min;
	uint32_t tseg1_max;
	uint32_t tseg2_min;
	uint32_t tseg2_max;
	uint32_t sjw_max;
	uint32_t brp_min;
	uint32_t brp_max;
	uint32_t brp_inc;
} __packed canivore_usb_bt_const_t;

/* Only send a max of CANIVORE_MAX_TX_URBS frames at a time. */
#define CANIVORE_MAX_TX_URBS 10
/* Only launch a max of CANIVORE_MAX_RX_URBS usb requests at a time. */
#define CANIVORE_MAX_RX_URBS 30
/* Do not queue new tx requests unless there are CANIVORE_TX_URB_PER_REQ urbs free. */
#define CANIVORE_TX_URB_PER_REQ 2

/* struct to hold information for the async tx callback */
typedef struct _canivore_usb_tx_context_t {
	struct _canivore_usb_can_t *dev;
	unsigned int urb_id;
} canivore_usb_tx_context_t;

/* can interface struct */
typedef struct _canivore_usb_can_t {
	struct can_priv can; /* must be the first member */

	struct _canivore_usb_t *parent;

	struct net_device *netdev;
	struct usb_device *udev;
	struct usb_interface *intf;
	uint8_t bulk_in_addr;
	uint8_t bulk_out_addr;

	uint8_t busutil;
	struct can_berr_counter bec;
	struct can_bittiming_const bt_const;
	struct can_bittiming_const data_bt_const;

	/* lock for tx interrupt */
	spinlock_t tx_ctx_lock;
	struct _canivore_usb_tx_context_t tx_context[CANIVORE_MAX_TX_URBS];

	struct usb_anchor tx_submitted;
	atomic_t active_tx_urbs;

	/* mutex for user thread ioctl calls */
	struct mutex ioctl_mutex;

	void *inst_vars; /* instance variables */
	size_t rx_buffer_cap;
} canivore_usb_can_t;

/* top-level usb interface struct */
typedef struct _canivore_usb_t {
	struct _canivore_usb_can_t *canch;
	struct usb_anchor rx_submitted;
	struct usb_device *udev;
} canivore_usb_t;

/*
 * "Allocate" a tx context.
 * Returns a valid tx context or NULL if all are in use.
 */
static canivore_usb_tx_context_t *canivore_usb_alloc_tx_context(canivore_usb_can_t *dev)
{
	int i;
	canivore_usb_tx_context_t *txc = NULL;
	unsigned long flags;

	spin_lock_irqsave(&dev->tx_ctx_lock, flags);

	for (i = 0; i < CANIVORE_MAX_TX_URBS; ++i) {
		if (dev->tx_context[i].urb_id == CANIVORE_MAX_TX_URBS) {
			dev->tx_context[i].urb_id = i;
			txc = &dev->tx_context[i];
			break;
		}
	}

	spin_unlock_irqrestore(&dev->tx_ctx_lock, flags);
	return txc;
}

/* releases a tx context */
static void canivore_usb_free_tx_context(canivore_usb_tx_context_t *txc)
{
	txc->urb_id = CANIVORE_MAX_TX_URBS;
}

static int canivore_usb_rx_handler_1(void *device, void const *f)
{
	canivore_usb_can_t *dev = device;
	struct net_device *netdev;
	struct can_frame *cf;
	struct canfd_frame *cfd;
	struct sk_buff *skb;
	canivore_usb_can_flags_t flags;
	struct skb_shared_hwtstamps *hwts;
	uint64_t timestamp_ns;

	netdev = dev->netdev;

	if (!netif_device_present(netdev)) {
		return -1;
	}

	if (canivore_usb_is_frame_fd(f)) {
		skb = alloc_canfd_skb(dev->netdev, &cfd);
		if (!skb) {
			return -1;
		}

		hwts = skb_hwtstamps(skb);

		memset(&flags, 0, sizeof(flags));
		canivore_usb_get_single_frame_data(f, &cfd->can_id, &cfd->len,
						cfd->data, &timestamp_ns, &flags);

		hwts->hwtstamp = ns_to_ktime(timestamp_ns);

		if (flags.brs) {
			cfd->flags |= CANFD_BRS;
		}

		netdev->stats.rx_bytes += cfd->len;
	} else {
		skb = alloc_can_skb(dev->netdev, &cf);
		if (!skb) {
			return -1;
		}

		hwts = skb_hwtstamps(skb);

		memset(&flags, 0, sizeof(flags));
		canivore_usb_get_single_frame_data(f, &cf->can_id, &cf->can_dlc,
						cf->data, &timestamp_ns, &flags);

		hwts->hwtstamp = ns_to_ktime(timestamp_ns);

		netdev->stats.rx_bytes += cf->can_dlc;
	}

	netdev->stats.rx_packets++;

	netif_rx(skb);
	
	return 0;
}
static int canivore_usb_rx_handler_2(void *device, void const *a, void const *b)
{
	canivore_usb_can_t *dev = device;
	struct net_device *netdev;
	struct canfd_frame *cf;
	struct sk_buff *skb;
	canivore_usb_can_flags_t flags;
	struct skb_shared_hwtstamps *hwts;
	uint64_t timestamp_ns;

	netdev = dev->netdev;

	if (!netif_device_present(netdev)) {
		return -1;
	}
	
	skb = alloc_canfd_skb(dev->netdev, &cf);
	if (!skb) {
		return -1;
	}

	hwts = skb_hwtstamps(skb);

	memset(&flags, 0, sizeof(flags));
	canivore_usb_get_a_frame_data(a, b, &cf->can_id, &cf->len,
				cf->data, &timestamp_ns, &flags);

	hwts->hwtstamp = ns_to_ktime(timestamp_ns);

	if (flags.brs) {
		cf->flags |= CANFD_BRS;
	}

	netdev->stats.rx_packets++;
	netdev->stats.rx_bytes += cf->len;

	netif_rx(skb);
	
	return 0;
}
static int canivore_usb_rx_handler_3(void *device, void const *a, void const *b, void const *c)
{
	canivore_usb_can_t *dev = device;
	struct net_device *netdev;
	struct canfd_frame *cf;
	struct sk_buff *skb;
	canivore_usb_can_flags_t flags;
	struct skb_shared_hwtstamps *hwts;
	uint64_t timestamp_ns;

	netdev = dev->netdev;

	if (!netif_device_present(netdev)) {
		return -1;
	}
	
	{
		skb = alloc_canfd_skb(dev->netdev, &cf);
		if (!skb) {
			return -1;
		}

		hwts = skb_hwtstamps(skb);

		memset(&flags, 0, sizeof(flags));
		canivore_usb_get_a_frame_data(a, b, &cf->can_id, &cf->len,
					cf->data, &timestamp_ns, &flags);

		hwts->hwtstamp = ns_to_ktime(timestamp_ns);

		if (flags.brs) {
			cf->flags |= CANFD_BRS;
		}

		netdev->stats.rx_packets++;
		netdev->stats.rx_bytes += cf->len;

		netif_rx(skb);
	}

	{
		skb = alloc_canfd_skb(dev->netdev, &cf);
		if (!skb) {
			return -1;
		}

		hwts = skb_hwtstamps(skb);

		memset(&flags, 0, sizeof(flags));
		canivore_usb_get_c_frame_data(c, b, &cf->can_id, &cf->len,
					cf->data, &timestamp_ns, &flags);

		hwts->hwtstamp = ns_to_ktime(timestamp_ns);

		if (flags.brs) {
			cf->flags |= CANFD_BRS;
		}

		netdev->stats.rx_packets++;
		netdev->stats.rx_bytes += cf->len;

		netif_rx(skb);
	}
	
	return 0;
}

static void canivore_usb_rx_resync_callback(struct urb *urb)
{
	kfree(urb->context);
	usb_free_coherent(urb->dev,
			  urb->transfer_buffer_length,
			  urb->transfer_buffer,
			  urb->transfer_dma);
}

static int canivore_usb_rx_resync_handler(void *device)
{
	canivore_usb_can_t *dev = device;
	struct urb *urb;
	struct usb_ctrlrequest *ctl_req;
	uint64_t *ktime;
	int retval;

	urb = usb_alloc_urb(0, GFP_ATOMIC);
	if (!urb) {
		dev_err(&dev->intf->dev,
			"Couldn't set the timestamp (err=%d)\n",
			ENOMEM);
		return ENOMEM;
	}

	ctl_req = kmalloc(sizeof(*ctl_req), GFP_KERNEL);
	if (!ctl_req) {
		dev_err(&dev->intf->dev,
			"Couldn't set the timestamp (err=%d)\n",
			ENOMEM);
		usb_free_urb(urb);
		return ENOMEM;
	}

	ktime = usb_alloc_coherent(dev->udev, sizeof(*ktime), GFP_ATOMIC,
				&urb->transfer_dma);
	if (!ktime) {
		dev_err(&dev->intf->dev,
			"Couldn't set the timestamp (err=%d)\n",
			ENOMEM);
		kfree(ctl_req);
		usb_free_urb(urb);
		return ENOMEM;
	}

	*ktime = ktime_get_ns();

	/* set timestamp */
	ctl_req->bRequestType = USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_INTERFACE;
	ctl_req->bRequest = canivore_usb_breq_set_timestamp;
	ctl_req->wValue = 0;
	ctl_req->wIndex = dev->intf->cur_altsetting->desc.bInterfaceNumber;
	ctl_req->wLength = sizeof(*ktime);

	usb_fill_control_urb(urb, dev->udev,
			     usb_sndctrlpipe(dev->udev, 0),
			     (uint8_t *)ctl_req, ktime,
			     sizeof(*ktime),
			     canivore_usb_rx_resync_callback,
			     ctl_req);

	urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
	usb_anchor_urb(urb, &dev->tx_submitted);

	retval = usb_submit_urb(urb, GFP_ATOMIC);

	if (retval < 0) {
		kfree(ctl_req);
		usb_unanchor_urb(urb);
		usb_free_coherent(dev->udev,
				  sizeof(*ktime),
				  ktime,
				  urb->transfer_dma);
	}

	usb_free_urb(urb);

	if (retval < 0) {
		dev_err(&dev->intf->dev,
			"Couldn't set the timestamp (err=%d)\n",
			retval);
		return retval;
	}

	return 0;
}

static int canivore_usb_rx_busutil_handler(void *device, uint8_t busutil)
{
	canivore_usb_can_t *dev = device;

	dev->busutil = busutil;

	return 0;
}

static int canivore_usb_rx_error_handler(void *device, uint8_t tec, uint8_t rec, canivore_usb_err_flags_t err_flags)
{
	canivore_usb_can_t *dev = device;
	struct can_device_stats *can_stats;

	can_stats = &dev->can.can_stats;

	dev->bec.txerr = tec;
	dev->bec.rxerr = rec;

	if (err_flags.bus_error) {
		++can_stats->bus_error;
	}
	if (err_flags.arbitration_lost) {
		++can_stats->arbitration_lost;
	}
	if (err_flags.restart) {
		++can_stats->restarts;
	}

	if (tec < 96 && rec < 96) {
		dev->can.state = CAN_STATE_ERROR_ACTIVE;
	} else if (tec < 128 && rec < 128) {
		dev->can.state = CAN_STATE_ERROR_WARNING;
		++can_stats->error_warning;
	} else if (tec < 256 && rec < 256) {
		dev->can.state = CAN_STATE_ERROR_PASSIVE;
		++can_stats->error_passive;
	} else {
		dev->can.state = CAN_STATE_BUS_OFF;
		++can_stats->bus_off;
	}

	return 0;
}

static int canivore_usb_rx_dropped_handler(void *device)
{
	canivore_usb_can_t *dev = device;
	struct net_device *netdev = dev->netdev;

	netdev->stats.rx_dropped++;

	return 0;
}

/* NOTE: canivore_usb_create calls canivore_usb_set_rx_handlers */
static canivore_usb_rx_handlers_t const canivore_usb_rx_handlers = {
	.rx_handler_1 = canivore_usb_rx_handler_1,
	.rx_handler_2 = canivore_usb_rx_handler_2,
	.rx_handler_3 = canivore_usb_rx_handler_3,
	.rx_resync_handler = canivore_usb_rx_resync_handler,
	.rx_busutil_handler = canivore_usb_rx_busutil_handler,
	.rx_error_handler = canivore_usb_rx_error_handler,
	.rx_dropped_handler = canivore_usb_rx_dropped_handler,
};

static void canivore_usb_rx_bulk_callback(struct urb *urb)
{
	canivore_usb_t *usbcan = urb->context;
	canivore_usb_can_t *dev;
	uint8_t *frameEndPt;
	int retval;

	BUG_ON(!usbcan);

	switch (urb->status) {
	case 0: /* success */
		break;
	case -ENOENT:
	case -ESHUTDOWN:
		return;
	default:
		/* do not resubmit aborted urbs. eg: when device goes down */
		return;
	}

	dev = usbcan->canch;

	frameEndPt = urb->transfer_buffer;

	retval = canivore_usb_manage_frame_rx(dev, frameEndPt, urb->actual_length, dev->inst_vars);
	if (retval != 0) {
		return;
	}

	usb_fill_bulk_urb(urb,
			  usbcan->udev,
			  usb_rcvbulkpipe(usbcan->udev, dev->bulk_in_addr),
			  frameEndPt,
			  dev->rx_buffer_cap,
			  canivore_usb_rx_bulk_callback,
			  usbcan
			  );

	retval = usb_submit_urb(urb, GFP_ATOMIC);

	/* USB failure, take down all interfaces */
	if (retval == -ENODEV) {
		if (usbcan->canch) {
			netif_device_detach(usbcan->canch->netdev);
		}
	}
}

static void canivore_usb_inc_active_tx_urbs(struct net_device *netdev)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);

	atomic_inc(&dev->active_tx_urbs);
	if (atomic_read(&dev->active_tx_urbs) > CANIVORE_MAX_TX_URBS - CANIVORE_TX_URB_PER_REQ) {
		/* no more tx URBs, stop the queue */
		netif_stop_queue(netdev);
	}
}

static void canivore_usb_dec_active_tx_urbs(struct net_device *netdev)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);

	atomic_dec(&dev->active_tx_urbs);
	if (atomic_read(&dev->active_tx_urbs) <= CANIVORE_MAX_TX_URBS - CANIVORE_TX_URB_PER_REQ) {
		/* we have free tx URBs, wake the queue */
		netif_wake_queue(netdev);
	}
}

static void canivore_usb_tx_callback(struct urb *urb)
{
	canivore_usb_tx_context_t *txc = urb->context;
	canivore_usb_can_t *dev = txc->dev;
	struct net_device *netdev = dev->netdev;

	if (urb->status) {
		netdev_info(netdev, "usb tx fail %d\n", txc->urb_id);
	}

	/* since we don't echo CAN frames, handle Tx success here */

	++netdev->stats.tx_packets;
	netdev->stats.tx_bytes += canivore_usb_get_frame_data_len(urb->transfer_buffer);

	canivore_usb_free_tx_context(txc);
	canivore_usb_dec_active_tx_urbs(netdev);

	usb_free_coherent(urb->dev,
			  urb->transfer_buffer_length,
			  urb->transfer_buffer,
			  urb->transfer_dma);
}

static int canivore_usb_tx_helper(struct sk_buff *skb,
				struct net_device *netdev,
				canivore_usb_tx_context_t *txc,
				canivore_usb_get_tx_size_t get_tx_size,
				canivore_usb_prepare_frame_tx_t prepare_frame_tx)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);
	struct urb *urb;
	struct can_frame *cf;
	struct canfd_frame *cfd;
	void *frame;
	void *frame_usb;
	canivore_usb_can_flags_t flags;
	int retval;
	int retval_tx;
	unsigned int urb_id;

	urb_id = txc->urb_id;

	if (urb_id >= CANIVORE_MAX_TX_URBS) {
		netdev_err(netdev, "Invalid tx context %d\n", urb_id);
		goto bad_urb_id;
	}

	urb = usb_alloc_urb(0, GFP_ATOMIC);
	if (!urb) {
		goto nomem_urb;
	}

	frame = kzalloc(get_tx_size(0), GFP_ATOMIC);
	if (!frame) {
		netdev_err(netdev, "Could not allocate transmit\n");
		goto nomem_frame;
	}

	if (can_is_canfd_skb(skb)) {
		cfd = (struct canfd_frame *)skb->data;

		memset(&flags, 0, sizeof(flags));
		flags.brs = (cfd->flags & CANFD_BRS) != 0;
		flags.fdf = 1;

		retval_tx = prepare_frame_tx(frame, cfd->can_id, cfd->len, cfd->data,
					ktime_get_ns(), &flags, dev->inst_vars);
	} else {
		cf = (struct can_frame *)skb->data;

		memset(&flags, 0, sizeof(flags));
		flags.fdf = 0;

		if (cf->can_dlc > 8) {
			cf->can_dlc = 8;
		}
		retval_tx = prepare_frame_tx(frame, cf->can_id, cf->can_dlc, cf->data,
					ktime_get_ns(), &flags, dev->inst_vars);
	}

	frame_usb = usb_alloc_coherent(dev->udev, get_tx_size(frame), GFP_ATOMIC,
					&urb->transfer_dma);
	if (!frame_usb) {
		netdev_err(netdev, "Could not allocate transmit\n");
		kfree(frame);
		goto nomem_frame;
	}

	memcpy(frame_usb, frame, get_tx_size(frame));
	kfree(frame);

	usb_fill_bulk_urb(urb, dev->udev,
			  usb_sndbulkpipe(dev->udev, dev->bulk_out_addr),
			  frame_usb,
			  get_tx_size(frame_usb),
			  canivore_usb_tx_callback,
			  txc);

	urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
	usb_anchor_urb(urb, &dev->tx_submitted);

	canivore_usb_inc_active_tx_urbs(netdev);

	retval = usb_submit_urb(urb, GFP_ATOMIC);
	if (unlikely(retval)) { /* usb send failed */
		canivore_usb_dec_active_tx_urbs(netdev);

		can_free_echo_skb(netdev, urb_id);
		canivore_usb_free_tx_context(txc);

		usb_unanchor_urb(urb);
		usb_free_coherent(dev->udev,
				  get_tx_size(frame_usb),
				  frame_usb,
				  urb->transfer_dma);

		if (retval == -ENODEV) {
			netif_device_detach(netdev);
		} else {
			netdev_err(netdev, "usb_submit failed (err=%d)\n", retval);
			netdev->stats.tx_dropped++;
		}

		/* tx failed, don't try another */
		retval_tx = 0;
	}

	usb_free_urb(urb);

	return retval_tx;

 nomem_frame:
	usb_free_urb(urb);

 nomem_urb:
 bad_urb_id:
	canivore_usb_free_tx_context(txc);
	dev_kfree_skb(skb);
	netdev->stats.tx_dropped++;
	return -1;
}

static netdev_tx_t canivore_usb_start_tx(struct sk_buff *skb,
					struct net_device *netdev)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);
	canivore_usb_tx_context_t *txc;
	int retval;

	if (unlikely(can_dropped_invalid_skb(netdev, skb))) {
		return NETDEV_TX_OK;
	}

	txc = canivore_usb_alloc_tx_context(dev);
	if (unlikely(!txc)) {
		return NETDEV_TX_BUSY;
	}

	retval = canivore_usb_tx_helper(skb, netdev, txc,
					canivore_usb_get_tx1_size,
					canivore_usb_prepare_frame_tx1);

	if (retval > 0) {
		txc = canivore_usb_alloc_tx_context(dev);
		if (unlikely(!txc)) {
			return NETDEV_TX_BUSY;
		}

		retval = canivore_usb_tx_helper(skb, netdev, txc,
						canivore_usb_get_tx2_size,
						canivore_usb_prepare_frame_tx2);
	}

	if (retval < 0) {
		goto exit;
	}

	dev_kfree_skb(skb);

 exit:
	return NETDEV_TX_OK;
}

static int canivore_usb_cmd_enable(canivore_usb_can_t *dev, uint32_t flags)
{
	uint16_t *enableReq;
	struct usb_interface *intf = dev->intf;
	int retval;

	enableReq = kcalloc(6, sizeof(*enableReq), GFP_KERNEL);
	if (!enableReq) {
		return -ENOMEM;
	}

	canivore_usb_fill_enable_req(enableReq, 6, flags, dev->rx_buffer_cap);
	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_sndctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_set_enable,
				 USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 enableReq,
				 6 * sizeof(*enableReq),
				 CANIVORE_USB_TIMEOUT);

	kfree(enableReq);

	return retval;
}

static int canivore_usb_cmd_disable(canivore_usb_can_t *dev)
{
	uint8_t *disableReq;
	struct usb_interface *intf = dev->intf;
	int retval;

	disableReq = kmalloc(sizeof(*disableReq), GFP_KERNEL);
	if (!disableReq) {
		return -ENOMEM;
	}

	*disableReq = 0;
	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_sndctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_set_disable,
				 USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 disableReq,
				 sizeof(*disableReq),
				 CANIVORE_USB_TIMEOUT);

	kfree(disableReq);

	return retval;
}

static int canivore_usb_open(struct net_device *netdev)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);
	canivore_usb_t *parent = dev->parent;
	int retval, i;
	uint32_t ctrlmode;
	uint32_t flags = 0;

	retval = open_candev(netdev);
	if (retval) {
		return retval;
	}

	for (i = 0; i < CANIVORE_MAX_RX_URBS; ++i) {
		struct urb *urb;
		uint8_t *rx_buf;

		/* allocate rx urb */
		urb = usb_alloc_urb(0, GFP_KERNEL);
		if (!urb) {
			return -ENOMEM;
		}

		/* allocate rx buffer */
		rx_buf = usb_alloc_coherent(dev->udev,
					    dev->rx_buffer_cap,
					    GFP_KERNEL,
					    &urb->transfer_dma);
		if (!rx_buf) {
			netdev_err(netdev, "Could not allocate receive\n");
			usb_free_urb(urb);
			return -ENOMEM;
		}

		usb_fill_bulk_urb(urb,
				  dev->udev,
				  usb_rcvbulkpipe(dev->udev,
						  dev->bulk_in_addr),
				  rx_buf,
				  dev->rx_buffer_cap,
				  canivore_usb_rx_bulk_callback,
				  parent);
		urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

		usb_anchor_urb(urb, &parent->rx_submitted);

		retval = usb_submit_urb(urb, GFP_KERNEL);
		if (retval) {
			if (retval == -ENODEV) {
				netif_device_detach(dev->netdev);
			}

			netdev_err(netdev,
				   "usb_submit failed (err=%d)\n",
				   retval);

			usb_unanchor_urb(urb);
			usb_free_coherent(dev->udev,
					  dev->rx_buffer_cap,
					  rx_buf,
					  urb->transfer_dma);
			usb_free_urb(urb);
			break;
		}

		/* drop URB reference */
		usb_free_urb(urb);
	}

	ctrlmode = dev->can.ctrlmode;
	if (ctrlmode & CAN_CTRLMODE_LOOPBACK) {
		flags |= canivore_usb_loopback;
	}
	if (ctrlmode & CAN_CTRLMODE_LISTENONLY) {
		flags |= canivore_usb_listenonly;
	}
	if (ctrlmode & CAN_CTRLMODE_3_SAMPLES) {
		flags |= canivore_usb_3_samples;
	}
	if (ctrlmode & CAN_CTRLMODE_ONE_SHOT) {
		flags |= canivore_usb_one_shot;
	}
	if (ctrlmode & CAN_CTRLMODE_BERR_REPORTING) {
		flags |= canivore_usb_berr_reporting;
	}
	if (ctrlmode & CAN_CTRLMODE_FD) {
		flags |= canivore_usb_fd;
	}
	if (ctrlmode & CAN_CTRLMODE_PRESUME_ACK) {
		flags |= canivore_usb_presume_ack;
	}
	if (ctrlmode & CAN_CTRLMODE_FD_NON_ISO) {
		flags |= canivore_usb_fd_non_iso;
	}

	/* enable the device */
	retval = canivore_usb_cmd_enable(dev, flags);
	if (retval < 0) {
		netdev_err(netdev, "Couldn't start device (err=%d)\n", retval);
		return retval;
	}

	dev->can.state = CAN_STATE_ERROR_ACTIVE;

	if (!(dev->can.ctrlmode & CAN_CTRLMODE_LISTENONLY)) {
		netif_start_queue(netdev);
	}

	return 0;
}

static int canivore_usb_close(struct net_device *netdev)
{
	int retval;
	canivore_usb_can_t *dev = netdev_priv(netdev);
	canivore_usb_t *parent = dev->parent;

	netif_stop_queue(netdev);

	/* stop polling */
	usb_kill_anchored_urbs(&parent->rx_submitted);

	/* stop sending URBs */
	usb_kill_anchored_urbs(&dev->tx_submitted);
	atomic_set(&dev->active_tx_urbs, 0);

	/* disable the device */
	retval = canivore_usb_cmd_disable(dev);
	if (retval < 0) {
		netdev_warn(netdev, "Couldn't shutdown device (err=%d)", retval);
	}

	/* reset tx contexts */
	for (retval = 0; retval < CANIVORE_MAX_TX_URBS; retval++) {
		dev->tx_context[retval].dev = dev;
		dev->tx_context[retval].urb_id = CANIVORE_MAX_TX_URBS;
	}

	/* close the netdev */
	close_candev(netdev);

	return 0;
}

/*
 * Fork of usb_ifnum_to_if that takes the interface
 * protocol instead of the interface number.
 * Requires interface protocols to be unique.
 */
static struct usb_interface *usb_ifprot_to_if(struct usb_device const *dev,
						unsigned ifprot)
{
	struct usb_host_config *config = dev->actconfig;
	int i;

	if (!config)
		return NULL;
	for (i = 0; i < config->desc.bNumInterfaces; i++)
		if (config->interface[i]->altsetting[0]
				.desc.bInterfaceProtocol == ifprot)
			return config->interface[i];

	return NULL;
}

static int canivore_usb_ioctl_diag_helper(struct net_device *netdev, struct ifreq *ifr)
{
	int retval = 0;
	uint8_t *data;
	uint16_t len;
	int rx_len;
	uint16_t rx_timeout;
	canivore_usb_can_t *dev = netdev_priv(netdev);
	struct usb_endpoint_descriptor *bulk_in, *bulk_out;

	retval = usb_find_common_endpoints(usb_ifprot_to_if(dev->udev, canivore_usb_ioctl_ifprot)->cur_altsetting,
					   &bulk_in, &bulk_out,
					   NULL, NULL);
	if (retval) {
		netdev_err(netdev, "Could not find ioctl bulk-in and bulk-out endpoints\n");
		return retval;
	}

	/* send ioctl command */
	{
		len = canivore_usb_get_ioctl_tx_len(ifr->ifr_data);
		if (!len) {
			return -EINVAL;
		}

		data = kcalloc(len, sizeof(*data), GFP_KERNEL);
		if (!data) {
			netdev_err(netdev, "Could not allocate ioctl transmit\n");
			return -ENOMEM;
		}

		retval = canivore_usb_fill_ioctl_tx_data(ifr->ifr_data, data, len);
		if (retval) {
			netdev_err(netdev, "Could not get ioctl data from user (err=%d)\n", retval);
			kfree(data);
			return -EFAULT;
		}

		retval = usb_bulk_msg(dev->udev,
				      usb_sndbulkpipe(dev->udev, bulk_out->bEndpointAddress),
				      data,
				      len,
				      NULL,
				      CANIVORE_USB_TIMEOUT);

		kfree(data);

		if (retval < 0) {
			int tx_retval;

			netdev_err(netdev, "Could not send ioctl command (err=%d)\n", retval);

			tx_retval = canivore_usb_fill_ioctl_tx_error(ifr->ifr_data);
			if (tx_retval) {
				retval = tx_retval;
			}
			return retval;
		}
	}

	/* get ioctl response */
	{
		canivore_usb_fill_ioctl_rx_info(ifr->ifr_data, &len, &rx_timeout);
		if (!len) {
			return -EINVAL;
		}

		if (!rx_timeout) {
			rx_timeout = CANIVORE_USB_TIMEOUT;
		}

		data = kcalloc(len, sizeof(*data), GFP_KERNEL);
		if (!data) {
			netdev_err(netdev, "Could not allocate ioctl receive\n");
			return -ENOMEM;
		}

		retval = usb_bulk_msg(dev->udev,
				      usb_rcvbulkpipe(dev->udev, bulk_in->bEndpointAddress),
				      data,
				      len,
				      &rx_len,
				      rx_timeout);

		if (retval < 0) {
			int rx_retval;

			netdev_err(netdev, "Could not get ioctl response (err=%d)\n", retval);
			kfree(data);

			rx_retval = canivore_usb_fill_ioctl_rx_error(ifr->ifr_data);
			if (rx_retval) {
				retval = rx_retval;
			}
			return retval;
		}

		retval = canivore_usb_fill_ioctl_rx_data(ifr->ifr_data, data, rx_len);
		kfree(data);
		if (retval) {
			netdev_err(netdev, "Could not send ioctl response to user (err=%d)\n", retval);
			return -EFAULT;
		}
	}

	return retval;
}

static int canivore_usb_ioctl_busutil_helper(struct net_device *netdev, struct ifreq *ifr)
{
	int retval = 0;
	canivore_usb_can_t *dev = netdev_priv(netdev);

	retval = copy_to_user(ifr->ifr_data, &dev->busutil, sizeof(dev->busutil));
	if (retval) {
		netdev_err(netdev, "Could not send ioctl response to user (err=%d)\n", retval);
		return -EFAULT;
	}

	return retval;
}

static int canivore_usb_ioctl(struct net_device *netdev, struct ifreq *ifr, int cmd)
{
	int retval = 0;
	canivore_usb_can_t *dev = netdev_priv(netdev);

	mutex_lock(&dev->ioctl_mutex);
	if (cmd == SIOCDEVPRIVATE + canivore_usb_ioctl_diag) {
		retval = canivore_usb_ioctl_diag_helper(netdev, ifr);
	} else if (cmd == SIOCDEVPRIVATE + canivore_usb_ioctl_busutil) {
		retval = canivore_usb_ioctl_busutil_helper(netdev, ifr);
	} else {
		retval = -EOPNOTSUPP;
	}
	mutex_unlock(&dev->ioctl_mutex);

	return retval;
}

static struct net_device_ops const canivore_usb_netdev_ops = {
	.ndo_open = canivore_usb_open,
	.ndo_stop = canivore_usb_close,
	.ndo_start_xmit = canivore_usb_start_tx,
	.ndo_do_ioctl = canivore_usb_ioctl,
	.ndo_change_mtu = can_change_mtu,
};

static int canivore_usb_get_berr_counter(struct net_device const *netdev, struct can_berr_counter *bec)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);
	*bec = dev->bec;

	return 0;
}

static int canivore_usb_set_bittiming(struct net_device *netdev)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);
	struct can_bittiming *bt = &dev->can.bittiming;
	struct usb_interface *intf = dev->intf;
	int retval;
	canivore_usb_bittiming_t *dbt;

	dbt = kmalloc(sizeof(*dbt), GFP_KERNEL);
	if (!dbt) {
		return -ENOMEM;
	}

	dbt->prop_seg = bt->prop_seg;
	dbt->phase_seg1 = bt->phase_seg1;
	dbt->phase_seg2 = bt->phase_seg2;
	dbt->sjw = bt->sjw;
	dbt->brp = bt->brp;

	/* request bit timings */
	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_sndctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_set_bittiming,
				 USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 dbt,
				 sizeof(*dbt),
				 CANIVORE_USB_TIMEOUT);

	kfree(dbt);

	if (retval < 0) {
		dev_err(netdev->dev.parent, "Couldn't set bittimings (err=%d)",
			retval);
		return retval;
	}

	return 0;
}

static int canivore_usb_set_data_bittiming(struct net_device *netdev)
{
	canivore_usb_can_t *dev = netdev_priv(netdev);
	struct can_bittiming *data_bt = &dev->can.data_bittiming;
	struct usb_interface *intf = dev->intf;
	int retval;
	canivore_usb_bittiming_t *dbt;

	dbt = kmalloc(sizeof(*dbt), GFP_KERNEL);
	if (!dbt) {
		return -ENOMEM;
	}

	dbt->prop_seg = data_bt->prop_seg;
	dbt->phase_seg1 = data_bt->phase_seg1;
	dbt->phase_seg2 = data_bt->phase_seg2;
	dbt->sjw = data_bt->sjw;
	dbt->brp = data_bt->brp;

	/* request bit timings */
	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_sndctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_set_data_bittiming,
				 USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 dbt,
				 sizeof(*dbt),
				 CANIVORE_USB_TIMEOUT);

	kfree(dbt);

	if (retval < 0) {
		dev_err(netdev->dev.parent, "Couldn't set data bittimings (err=%d)",
			retval);
		return retval;
	}

	return 0;
}

static canivore_usb_can_t *canivore_usb_create(struct usb_interface *intf)
{
	canivore_usb_can_t *dev;
	struct net_device *netdev;
	int retval;
	canivore_usb_bt_const_t *bt_const;
	canivore_usb_bt_const_t *data_bt_const;
	uint64_t *ktime;

	/* get bittiming constants */
	bt_const = kmalloc(sizeof(*bt_const), GFP_KERNEL);
	if (!bt_const) {
		return ERR_PTR(-ENOMEM);
	}

	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_rcvctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_get_bt_const,
				 USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 bt_const,
				 sizeof(*bt_const),
				 CANIVORE_USB_TIMEOUT);

	if (retval < 0) {
		dev_err(&intf->dev,
			"Couldn't get bit timing const (err=%d)\n",
			retval);
		kfree(bt_const);
		return ERR_PTR(retval);
	}

	/* get data bittiming constants for FD */
	data_bt_const = kmalloc(sizeof(*data_bt_const), GFP_KERNEL);
	if (!data_bt_const) {
		kfree(bt_const);
		return ERR_PTR(-ENOMEM);
	}

	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_rcvctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_get_data_bt_const,
				 USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 data_bt_const,
				 sizeof(*data_bt_const),
				 CANIVORE_USB_TIMEOUT);

	if (retval < 0) {
		dev_err(&intf->dev,
			"Couldn't get data bit timing const (err=%d)\n",
			retval);
		kfree(bt_const);
		kfree(data_bt_const);
		return ERR_PTR(retval);
	}

	/* create netdev */
	netdev = alloc_candev(sizeof(*dev), CANIVORE_MAX_TX_URBS);
	if (!netdev) {
		dev_err(&intf->dev, "Couldn't allocate candev\n");
		kfree(bt_const);
		kfree(data_bt_const);
		return ERR_PTR(-ENOMEM);
	}
	dev = netdev_priv(netdev);

	netdev->netdev_ops = &canivore_usb_netdev_ops;

	/* dev setup */
	strcpy(dev->bt_const.name, "canivore_usb");
	dev->bt_const.tseg1_min = bt_const->tseg1_min;
	dev->bt_const.tseg1_max = bt_const->tseg1_max;
	dev->bt_const.tseg2_min = bt_const->tseg2_min;
	dev->bt_const.tseg2_max = bt_const->tseg2_max;
	dev->bt_const.sjw_max = bt_const->sjw_max;
	dev->bt_const.brp_min = bt_const->brp_min;
	dev->bt_const.brp_max = bt_const->brp_max;
	dev->bt_const.brp_inc = bt_const->brp_inc;

	strcpy(dev->data_bt_const.name, "canivore_usb");
	dev->data_bt_const.tseg1_min = data_bt_const->tseg1_min;
	dev->data_bt_const.tseg1_max = data_bt_const->tseg1_max;
	dev->data_bt_const.tseg2_min = data_bt_const->tseg2_min;
	dev->data_bt_const.tseg2_max = data_bt_const->tseg2_max;
	dev->data_bt_const.sjw_max = data_bt_const->sjw_max;
	dev->data_bt_const.brp_min = data_bt_const->brp_min;
	dev->data_bt_const.brp_max = data_bt_const->brp_max;
	dev->data_bt_const.brp_inc = data_bt_const->brp_inc;

	dev->udev = interface_to_usbdev(intf);
	dev->intf = intf;
	dev->netdev = netdev;

	init_usb_anchor(&dev->tx_submitted);
	atomic_set(&dev->active_tx_urbs, 0);
	spin_lock_init(&dev->tx_ctx_lock);
	for (retval = 0; retval < CANIVORE_MAX_TX_URBS; retval++) {
		dev->tx_context[retval].dev = dev;
		dev->tx_context[retval].urb_id = CANIVORE_MAX_TX_URBS;
	}

	mutex_init(&dev->ioctl_mutex);

	/* can setup */
	dev->can.state = CAN_STATE_STOPPED;
	dev->can.clock.freq = bt_const->fclk_can;
	dev->can.bittiming_const = &dev->bt_const;
	dev->can.data_bittiming_const = &dev->data_bt_const;
	dev->can.do_get_berr_counter = canivore_usb_get_berr_counter;
	dev->can.do_set_bittiming = canivore_usb_set_bittiming;
	dev->can.do_set_data_bittiming = canivore_usb_set_data_bittiming;

	dev->can.ctrlmode_supported = 0;

	if (bt_const->feature & canivore_usb_loopback) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_LOOPBACK;
	}
	if (bt_const->feature & canivore_usb_listenonly) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_LISTENONLY;
	}
	if (bt_const->feature & canivore_usb_3_samples) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_3_SAMPLES;
	}
	if (bt_const->feature & canivore_usb_one_shot) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_ONE_SHOT;
	}
	if (bt_const->feature & canivore_usb_berr_reporting) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_BERR_REPORTING;
	}
	if (bt_const->feature & canivore_usb_fd) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_FD;
	}
	if (bt_const->feature & canivore_usb_presume_ack) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_PRESUME_ACK;
	}
	if (bt_const->feature & canivore_usb_fd_non_iso) {
		dev->can.ctrlmode_supported |= CAN_CTRLMODE_FD_NON_ISO;
	}

	SET_NETDEV_DEV(netdev, &intf->dev);

	kfree(bt_const);
	kfree(data_bt_const);

	ktime = kmalloc(sizeof(*ktime), GFP_KERNEL);
	if (!ktime) {
		free_candev(dev->netdev);
		return ERR_PTR(-ENOMEM);
	}

	*ktime = ktime_get_ns();

	/* set timestamp */
	retval = usb_control_msg(interface_to_usbdev(dev->intf),
				 usb_sndctrlpipe(interface_to_usbdev(dev->intf), 0),
				 canivore_usb_breq_set_timestamp,
				 USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 0,
				 dev->intf->cur_altsetting->desc.bInterfaceNumber,
				 ktime,
				 sizeof(*ktime),
				 CANIVORE_USB_TIMEOUT);

	kfree(ktime);

	if (retval < 0) {
		dev_err(&intf->dev,
			"Couldn't set the initial timestamp (err=%d)\n",
			retval);
		free_candev(dev->netdev);
		return ERR_PTR(retval);
	}

	dev->inst_vars = kzalloc(canivore_usb_inst_vars_sz, GFP_KERNEL);
	if (!dev->inst_vars) {
		free_candev(dev->netdev);
		return ERR_PTR(-ENOMEM);
	}

	canivore_usb_set_rx_handlers(&canivore_usb_rx_handlers, dev->inst_vars);

	retval = register_candev(dev->netdev);
	if (retval) {
		dev_err(&intf->dev, "Couldn't register candev (err=%d)\n", retval);
		kfree(dev->inst_vars);
		free_candev(dev->netdev);
		return ERR_PTR(retval);
	}

	return dev;
}

static void canivore_usb_destroy(canivore_usb_can_t *dev)
{
	unregister_candev(dev->netdev);
	usb_kill_anchored_urbs(&dev->tx_submitted);
	kfree(dev->inst_vars);
	free_candev(dev->netdev);
}

static int canivore_usb_probe(struct usb_interface *intf, const struct usb_device_id *id)
{
	canivore_usb_t *dev;
	struct usb_endpoint_descriptor *bulk_in, *bulk_out;
	int retval = -ENOMEM;
	uint32_t *mac_addr;
	size_t *rx_buffer_cap;
	struct net_device *netdev;

	retval = usb_find_common_endpoints(intf->cur_altsetting,
					   &bulk_in, &bulk_out,
					   NULL, NULL);
	if (retval) {
		dev_err(&intf->dev,
			"Could not find bulk-in and bulk-out endpoints\n");
		return retval;
	}

	dev = kzalloc(sizeof(*dev), GFP_KERNEL);
	if (!dev) {
		return -ENOMEM;
	}

	init_usb_anchor(&dev->rx_submitted);

	usb_set_intfdata(intf, dev);
	dev->udev = interface_to_usbdev(intf);

	dev->canch = canivore_usb_create(intf);
	if (IS_ERR_OR_NULL(dev->canch)) {
		/* get error code from pointer */
		retval = PTR_ERR(dev->canch);

		usb_kill_anchored_urbs(&dev->rx_submitted);
		kfree(dev);
		return retval;
	}
	dev->canch->parent = dev;

	dev->canch->bulk_in_addr = bulk_in->bEndpointAddress;
	dev->canch->bulk_out_addr = bulk_out->bEndpointAddress;

	/* read device MAC address */
	mac_addr = kcalloc(2, sizeof(*mac_addr), GFP_KERNEL);
	if (!mac_addr) {
		canivore_usb_destroy(dev->canch);
		kfree(dev);
		return -ENOMEM;
	}

	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_rcvctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_get_mac,
				 USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 1,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 mac_addr,
				 2 * sizeof(*mac_addr),
				 CANIVORE_USB_TIMEOUT);
	if (retval < 0) {
		dev_err(&intf->dev, "Couldn't get device MAC address: (err=%d)\n",
			retval);
		kfree(mac_addr);
		canivore_usb_destroy(dev->canch);
		kfree(dev);
		return retval;
	}

	netdev = dev->canch->netdev;

	netdev->addr_assign_type = NET_ADDR_PERM;
	memcpy(netdev->dev_addr, (uint8_t *)mac_addr, 2 * sizeof(*mac_addr));
	netdev->addr_len = 2 * sizeof(*mac_addr);

	kfree(mac_addr);

	/* read device RX buffer capacity */
	rx_buffer_cap = kzalloc(sizeof(*rx_buffer_cap), GFP_KERNEL);
	if (!rx_buffer_cap) {
		canivore_usb_destroy(dev->canch);
		kfree(dev);
		return -ENOMEM;
	}

	retval = usb_control_msg(interface_to_usbdev(intf),
				 usb_rcvctrlpipe(interface_to_usbdev(intf), 0),
				 canivore_usb_breq_get_rx_buffer_cap,
				 USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_INTERFACE,
				 1,
				 intf->cur_altsetting->desc.bInterfaceNumber,
				 rx_buffer_cap,
				 sizeof(*rx_buffer_cap),
				 CANIVORE_USB_TIMEOUT);
	if (retval < 0) {
		dev_warn(&intf->dev, "Couldn't get device RX buffer capacity: (err=%d)\n",
			retval);
		/* don't return an error, use a default */
		*rx_buffer_cap = canivore_usb_default_rx_buffer_cap;
	}

	dev->canch->rx_buffer_cap = *rx_buffer_cap;

	kfree(rx_buffer_cap);

	return 0;
}

static void canivore_usb_disconnect(struct usb_interface *intf)
{
	canivore_usb_t *dev = usb_get_intfdata(intf);
	usb_set_intfdata(intf, NULL);

	if (!dev) {
		dev_err(&intf->dev, "Disconnect (nodata)\n");
		return;
	}

	if (dev->canch) {
		canivore_usb_destroy(dev->canch);
	}

	usb_kill_anchored_urbs(&dev->rx_submitted);
	kfree(dev);
}

static const struct usb_device_id canivore_usb_table[] = {
	{ USB_DEVICE_INTERFACE_PROTOCOL(CANIVORE_USB_VENDOR_ID,
					CANIVORE_USB_PRODUCT_ID,
					CANIVORE_USB_INTF_PROTOCOL) },
	{} /* terminating entry */
};

MODULE_DEVICE_TABLE(usb, canivore_usb_table);

static struct usb_driver canivore_usb_driver = {
	.name       = "canivore_usb",
	.probe      = canivore_usb_probe,
	.disconnect = canivore_usb_disconnect,
	.id_table   = canivore_usb_table,
};

module_usb_driver(canivore_usb_driver);

MODULE_AUTHOR("CTR Electronics <support@ctr-electronics.com>");
MODULE_DESCRIPTION("CTR Electronics USB-to-CANbus device driver for CANivore.");
MODULE_LICENSE("GPL v2");
