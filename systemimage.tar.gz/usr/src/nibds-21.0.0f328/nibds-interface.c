#undef __NO_VERSION__
#include <linux/version.h>

#include <linux/string.h>
#include <linux/errno.h>
#ifdef MODULE
   #if defined(CONFIG_MODVERSIONS) && !defined(MODVERSIONS)
      #define MODVERSIONS
   #endif

   #ifdef MODVERSIONS
      #include <config/modversions.h>
   #endif

   #include <linux/module.h>
#endif

#include "nikal.h"

#ifdef MODULE_LICENSE
   #ifdef nNIKAL100_kCopyrightString
      MODULE_LICENSE(nNIKAL100_kCopyrightString);
   #endif
#endif

#ifdef MODULE_AUTHOR
   #ifdef nNIKAL100_kAuthorString
      MODULE_AUTHOR(nNIKAL100_kAuthorString);
   #endif
#endif

#ifdef MODULE_DESCRIPTION
   #ifdef nNIKAL100_kDescriptionString
      MODULE_DESCRIPTION(nNIKAL100_kDescriptionString);
   #endif
#endif


int nNIPAL100_ckalcbInitModule(void* modulePtr, const char* name);
void nNIPAL100_ckalcbCleanupModule(void* modulePtr);

int init_module(void)
{
   return nNIPAL100_ckalcbInitModule(THIS_MODULE,(THIS_MODULE)->name);
}

void cleanup_module(void)
{
   nNIPAL100_ckalcbCleanupModule(THIS_MODULE);
}


#define nNIKAL100_mExportSymbol EXPORT_SYMBOL
extern int nBDS_registerDriver;
nNIKAL100_mExportSymbol(nBDS_registerDriver);
extern int nBDS_unregisterDriver;
nNIKAL100_mExportSymbol(nBDS_unregisterDriver);
extern int nBDS_prepareToUnloadAndDestroyDevices;
nNIKAL100_mExportSymbol(nBDS_prepareToUnloadAndDestroyDevices);
extern int nBDS_removeWorkerThread;
nNIKAL100_mExportSymbol(nBDS_removeWorkerThread);
extern int nBDS_addWorkerThread;
nNIKAL100_mExportSymbol(nBDS_addWorkerThread);
extern int nBDS_getRootDevice_nolock;
nNIKAL100_mExportSymbol(nBDS_getRootDevice_nolock);
extern int nBDS_unlockTopology;
nNIKAL100_mExportSymbol(nBDS_unlockTopology);
extern int nBDS_lockTopology;
nNIKAL100_mExportSymbol(nBDS_lockTopology);
extern int nBDS_getNextChild_nolock;
nNIKAL100_mExportSymbol(nBDS_getNextChild_nolock);
extern int nBDS_getDeviceCurrentState;
nNIKAL100_mExportSymbol(nBDS_getDeviceCurrentState);
extern int nBDS_getDeviceTargetState;
nNIKAL100_mExportSymbol(nBDS_getDeviceTargetState);
extern int nBDS_unlockDevice;
nNIKAL100_mExportSymbol(nBDS_unlockDevice);
extern int nBDS_lockDevice;
nNIKAL100_mExportSymbol(nBDS_lockDevice);
extern int nBDS_requestDeviceEnumeration;
nNIKAL100_mExportSymbol(nBDS_requestDeviceEnumeration);
extern int nBDS_setPDOTargetState_nolock;
nNIKAL100_mExportSymbol(nBDS_setPDOTargetState_nolock);
extern int nBDS_linkPDOToParent_nolock;
nNIKAL100_mExportSymbol(nBDS_linkPDOToParent_nolock);
extern int nBDS_insertFDO;
nNIKAL100_mExportSymbol(nBDS_insertFDO);
extern int nBDS_destroyPDO;
nNIKAL100_mExportSymbol(nBDS_destroyPDO);
extern int nBDS_createPDO;
nNIKAL100_mExportSymbol(nBDS_createPDO);
