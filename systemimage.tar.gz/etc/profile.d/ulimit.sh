#
# Copyright (c) 2013 National Instruments
#

ulimit -s 512
